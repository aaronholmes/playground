//
//  main.cpp
//  FirstGame - TicTacToe
//
//  Created by Aaron Holmes on 2012-12-31.
//  Copyright (c) 2012 Aaron Holmes. All rights reserved.
//

#include <iostream>
#include <math.h>

using namespace std;

// Global Constants
const int ROWS = 3;
const int COLUMNS = 3;
char board[ROWS][COLUMNS] = { {'-', '-', '-'},
    {'-', '-', '-'},
    {'-', '-', '-'} };
int moveCount = 0;
int firstPlayerWins = 0;
int secondPlayerWins = 0;
int draws = 0;
char playerNames[1][100];

// Function Prototypes
void printInstructions();
void initializeGame();
void askPlayerNames();
void endGame();
void outputGameStats();
void clearGame();
void checkGameStatus(char board[ROWS][COLUMNS], int x, int y, int playerTurn);

// Function Definitions
void initializeGame() {
    printInstructions();
    askPlayerNames();
}

void printInstructions() {
    cout << "Welcome to Ghetto Tic Tac Toe!\n";
    cout << "You can choose your position by entering a number between 1 and 9. The number\n";
    cout << "corresponds to the desired board position, as illustrated:\n\n";
    cout << "\t\t1 | 2 | 3\n";
    cout << "\t\t—----———-\n";
    cout << "\t\t4 | 5 | 6\n";
    cout << "\t\t----————-\n";
    cout << "\t\t7 | 8 | 9\n\n";
}

void askPlayerNames() {
    cout << "Please enter Player 1's name: ";
    cin >> playerNames[0];
    cout << "\n";
    cout << "Please enter Player 2's name: ";
    cin >> playerNames[1];
    cout << "\n\n";
    
}

void endGame() {
    cout <<  "Thank you for playing!";
}

void outputGameStats() {
    cout << "Player 1: " << firstPlayerWins << " wins. Player 2: " << secondPlayerWins << " wins. " << draws << " draws\n";
}

void printboard(char board[ROWS][COLUMNS]) {
    for(int x = 0; x < ROWS; x++) {
        for(int y = 0; y < COLUMNS; y++) {
            cout << board[x][y];
        }
        cout << "\n";
    }
    return;
}

void clearGame() {
    for(int x = 0; x < ROWS; x++){
        for(int y = 0; y < COLUMNS; y++) {
            board[x][y] = '-';
        }
    }
    
    outputGameStats();
    cout << "\n";
    printboard(board);
}

void checkGameStatus(char board[ROWS][COLUMNS], int x, int y, int playerTurn) {
    bool gameFinished = false;
    char userLetter;
    
    if(playerTurn == 1) {
        userLetter = 'x';
    } else {
        userLetter = 'o';
    }
    
    cout << "You have made " << moveCount;
    if(moveCount == 1) {
        cout << " move\n";
    } else {
        cout << " moves\n";
    }
    
    //Check Col
    for(int i = 0; i < COLUMNS; i++){
        if(board[x][i] != userLetter) {
            break;
        }
            
        if(i == COLUMNS-1){
            cout << playerNames[playerTurn-1] << " has won!";
            if(playerTurn == 1) {
                firstPlayerWins++;
            } else {
                secondPlayerWins++;
            }
            gameFinished = true;
        }
    }
    
    //Check Row
    
    for(int i = 0; i < ROWS; i++){
        if(board[i][y] != userLetter) {
            break;
        }
        
        if(i == COLUMNS-1){
            cout << playerNames[playerTurn-1] << " has won!\n";
            if(playerTurn == 1) {
                firstPlayerWins++;
            } else {
                secondPlayerWins++;
            }
            gameFinished = true;
        }
    }
    
    //Check Diag
    if(x == y){
        //we're on a diagonal
        for(int i = 0; i < ROWS; i++){
            if(board[i][i] != userLetter)
                break;
            if(i == ROWS-1){
                cout << playerNames[playerTurn-1] << " has won!\n";
                if(playerTurn == 1) {
                    firstPlayerWins++;
                } else {
                    secondPlayerWins++;
                }
                gameFinished = true;
            }
        }
    }
    
    //Check Anti-Diag
    for(int i = 0;i<ROWS;i++){
        if(board[i][(ROWS-1)-i] != userLetter)
            break;
        if(i == ROWS-1){
            cout << playerNames[playerTurn-1] << " has won!\n";
            if(playerTurn == 1) {
                firstPlayerWins++;
            } else {
                secondPlayerWins++;
            }
            gameFinished = true;

        }
    }
    
    if(moveCount == pow(ROWS,2)) {
        cout << "The game is a draw!\n";
        draws++;
        gameFinished = true;
    }
    
    if(gameFinished) {
        moveCount = 0;
        clearGame();
    }
}

// Main Program
int main()
{
    
    int playerTurn = 1;
    
    initializeGame();
    printboard(board);
    
    while(true) {
        cout << "It is " <<  playerNames[playerTurn-1] << "'s turn!\n";
        cout << "Please select a space (1-9): ";
        
        int userSelection;
        cin >> userSelection;
        
        if(userSelection==0) break;
        
        if(userSelection > 0 && userSelection <=9) {
            int userRow = (userSelection-1) / 3;
            int userCol = (userSelection-1) % 3;
            
            if(board[userRow][userCol] != '-') {
                cout << "Space has already been taken, please choose another!\n";
                continue;
            }
            
            if(playerTurn == 1) {
                board[userRow][userCol] = 'x';
            } else {
                board[userRow][userCol] = 'o';
            }
            
            moveCount++;
            printboard(board);
            
            checkGameStatus(board, userRow, userCol, playerTurn);
            
            if(playerTurn == 1) {
                playerTurn = 2;
            } else {
                playerTurn = 1;
            }

        } else {
            cout << "Please choose a valid square.\n\n";
        }
    }
    
    endGame();
    
}



